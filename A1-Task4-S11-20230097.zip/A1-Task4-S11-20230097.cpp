#include <iostream>
#include <vector>
#include <iomanip>
#include <sstream>
#include <cmath>
#include <string>

class Register {
public:
    std::vector<int> memory;
    static const int size = 16;

    Register() {
        memory.resize(size, 0); // Initialize 16 registers
    }

    int getCell(int index) const {
        return memory[index];
    }

    void setCell(int index, int val) {
        memory[index] = val & 0xFF; // Keep within 8-bit range
    }
};

class Memory {
public:
    std::vector<std::string> memory;
    static const int size = 256;

    Memory() {
        memory.resize(size, "0000"); // Initialize 256 memory cells to "0000"
    }

    std::string getCell(int address) const {
        return memory[address];
    }

    void setCell(int address, const std::string& val) {
        memory[address] = val;
    }
};

class ALU {
public:
    int hexToDec(const std::string& hex) {
        return std::stoi(hex, nullptr, 16);
    }

    std::string decToHex(int dec) {
        std::stringstream ss;
        ss << std::hex << dec;
        return ss.str();
    }

    bool isValidHex(const std::string& str) {
        return str.size() <= 2 && str.find_first_not_of("0123456789ABCDEFabcdef") == std::string::npos;
    }

    void add(int idx1, int idx2, int idx3, Register& reg) {
        int result = reg.getCell(idx1) + reg.getCell(idx2);
        reg.setCell(idx3, result);
    }
};

class CU {
public:
    void load(int idxReg, int intMem, Register& reg, Memory& mem) {
        reg.setCell(idxReg, std::stoi(mem.getCell(intMem), nullptr, 16));
    }

    void store(int idxReg, int idxMem, Register& reg, Memory& mem) {
        mem.setCell(idxMem, decToHex(reg.getCell(idxReg)));
    }

    void move(int idxReg1, int idxReg2, Register& reg) {
        reg.setCell(idxReg2, reg.getCell(idxReg1));
    }

    void jump(int idxReg1, int idxMem, Register& reg, int& PC) {
        if (reg.getCell(idxReg1) == reg.getCell(0)) {
            PC = idxMem;
        }
    }

    void halt(bool& halted) {
        halted = true;
    }

private:
    std::string decToHex(int dec) {
        std::stringstream ss;
        ss << std::setw(2) << std::setfill('0') << std::hex << dec;
        return ss.str();
    }
};

class CPU {
public:
    int programCounter;
    int instructionRegister;
    Register reg;
    ALU alu;
    CU cu;
    bool halted;

    CPU() : programCounter(0), instructionRegister(0), halted(false) {}

    void runNextStep(Memory& mem) {
        instructionRegister = std::stoi(mem.getCell(programCounter), nullptr, 16);
        execute(mem);
        programCounter++;
    }

    void execute(Memory& mem) {
        int opcode = (instructionRegister & 0xF000) >> 12;
        int regIdx = (instructionRegister & 0x0F00) >> 8;
        int operand = instructionRegister & 0x00FF;

        switch (opcode) {
            case 0x1:
                cu.load(regIdx, operand, reg, mem);
                break;
            case 0x2:
                reg.setCell(regIdx, operand);
                break;
            case 0x3:
                cu.store(regIdx, operand, reg, mem);
                break;
            case 0x4:
                cu.move(regIdx, operand & 0x0F, reg);
                break;
            case 0x5:
                alu.add(regIdx, (operand >> 4) & 0x0F, operand & 0x0F, reg);
                break;
            case 0xC:
                cu.halt(halted);
                break;
            default:
                std::cerr << "Invalid instruction at PC: " << std::hex << programCounter << std::endl;
        }
    }
};

class Machine {
public:
    CPU processor;
    Memory memory;

    void loadProgramFile(const std::vector<std::string>& instructions) {
        for (size_t i = 0; i < instructions.size() && i < memory.size; ++i) {
            memory.setCell(i, instructions[i]);
        }
    }

    void outputState() const {
        std::cout << "\n--- Machine State ---\n";
        std::cout << "Program Counter: " << processor.programCounter << "\n";
        std::cout << "Instruction Register: " << std::hex << processor.instructionRegister << "\n";
        std::cout << "Registers: ";
        for (const auto& reg : processor.reg.memory) {
            std::cout << std::setw(2) << std::setfill('0') << std::hex << reg << " ";
        }
        std::cout << "\nMemory (first 16 cells): ";
        for (int i = 0; i < 16; ++i) {
            std::cout << memory.getCell(i) << " ";
        }
        std::cout << std::dec << std::endl;
    }
};

class MainUI {
public:
    Machine machine;

    void displayMenu() const {
        std::cout << "1. Load Program\n2. Run\n3. Display State\n4. Exit\n";
    }

    void inputChoice(char choice) {
        switch (choice) {
            case '1':
                inputFileName();
                break;
            case '2':
                while (!machine.processor.halted) {
                    machine.processor.runNextStep(machine.memory);
                }
                break;
            case '3':
                machine.outputState();
                break;
            case '4':
                exit(0);
            default:
                std::cerr << "Invalid choice!\n";
        }
    }

    void inputFileName() {
        std::vector<std::string> instructions = {"10E0", "11E1", "5201", "32E2", "C000"};
        machine.loadProgramFile(instructions);
    }
};

int main() {
    MainUI ui;
    char choice;
    while (true) {
        ui.displayMenu();
        std::cout << "Enter choice: ";
        std::cin >> choice;
        ui.inputChoice(choice);
    }
    return 0;
}
