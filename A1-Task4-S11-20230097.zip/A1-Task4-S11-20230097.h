// A1-Task4-s11-20230097.h

#ifndef A1_TASK4_S11_20230097_H

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <sstream>
#include <cmath>

// Class representing a set of 16 registers.
class Register {
public:
    std::vector<int> memory;
    static const int size = 16;

    Register();
    int getCell(int index) const;
    void setCell(int index, int val);
};

// Class representing memory with 256 cells.
class Memory {
public:
    std::vector<std::string> memory;
    static const int size = 256;

    Memory();
    std::string getCell(int address) const;
    void setCell(int address, const std::string& val);
};

// Arithmetic Logic Unit for handling arithmetic operations.
class ALU {
public:
    int hexToDec(const std::string& hex);
    std::string decToHex(int dec);
    bool isValidHex(const std::string& str);
    void add(int idx1, int idx2, int idx3, Register& reg);
};

// Control Unit to manage program flow.
class CU {
public:
    void load(int idxReg, int intMem, Register& reg, Memory& mem);
    void store(int idxReg, int idxMem, Register& reg, Memory& mem);
    void move(int idxReg1, int idxReg2, Register& reg);
    void jump(int idxReg1, int idxMem, Register& reg, int& PC);
    void halt(bool& halted);

private:
    std::string decToHex(int dec);
};

// CPU class integrating Register, ALU, and CU for program execution.
class CPU {
public:
    int programCounter;
    int instructionRegister;
    Register reg;
    ALU alu;
    CU cu;
    bool halted;

    CPU();
    void runNextStep(Memory& mem);
    void execute(Memory& mem);
};

// Machine class combining CPU and Memory.
class Machine {
public:
    CPU processor;
    Memory memory;

    void loadProgramFile(const std::vector<std::string>& instructions);
    void outputState() const;
};

// MainUI class to handle user interactions.
class MainUI {
public:
    Machine machine;

    void displayMenu() const;
    void inputChoice(char choice);
    void inputFileName();
};

#endif // A1_TASK4_S11_20230097_H
